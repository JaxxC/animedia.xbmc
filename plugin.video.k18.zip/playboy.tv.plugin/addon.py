#!/usr/bin/python
# -*- coding: utf-8 -*-

from xbmcswift2 import Plugin, xbmc, xbmcgui
from resources.lib.loader import WebLoader
from resources.lib.parser import Parser
import os


plugin = Plugin()
if __name__ == '__main__':
    _cookie_dir = os.path.dirname(__file__)
else:
    _cookie_dir = plugin.storage_path

urls = {
    'main': 'http://k18.co/',
    'category': 'http://k18.co/?cat=',
}

loader = WebLoader(_cookie_dir, urls['main'])
parser = Parser(plugin, loader)


@plugin.route('/')
def main_screen():
    page = loader.load_page(urls['main'])
    list = parser.parse_categories(page)
    return compose_main_screen(list)

def compose_main_screen(list):
    items = []
    for item in list:
        path = plugin.url_for('category', url =item['url'])
        items.append({'label': item['title'], 'path': path, 'thumbnail': item['image']})
    return items

@plugin.route('/category/<url>')
def category(url):
    page = loader.load_page(url)
    list = parser.parse_videos(page)
    return compose_category(list)

def compose_category(list):
    items = []
    for item in list:
        if item['image']:
            path = plugin.url_for('play', url =item['url'])
        else:
            path = plugin.url_for('category', url =item['url'])
        items.append({'label': item['title'], 'path': path, 'thumbnail': item['image']})
    return items

@plugin.route('/play/<url>')
def play(url):
    # items = []
    page = loader.load_page(url)
    url_frame = parser.parse_play(page)
    if(url_frame):
        frame = loader.load_page(url_frame['src'])
        video = parser.decode_openload(frame)
        listitem =xbmcgui.ListItem(video['title'], thumbnailImage=video['image'])
        xbmc.Player().play(video['videourl'], listitem)
    else:
        items = []
        list = parser.parse_images(page)
        for item in list:
            items.append({'label': item['title'], 'path': item['url'], 'thumbnail': item['image'], 'is_playable': True})
        plugin.set_content('files')
        return items


    # if video:
    #     items.append({'label': 'Play', 'path': video['videourl'], 'thumbnail': video['image'], 'is_playable': True})
    # return items

if __name__ == '__main__':
    plugin.run()
    plugin.set_content('movies')

