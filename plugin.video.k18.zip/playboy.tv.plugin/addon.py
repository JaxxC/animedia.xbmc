#!/usr/bin/python
# -*- coding: utf-8 -*-

from xbmcswift2 import Plugin
from resources.lib.loader import WebLoader
from resources.lib.parser import Parser
import os


plugin = Plugin()
if __name__ == '__main__':
    _cookie_dir = os.path.dirname(__file__)
else:
    _cookie_dir = plugin.storage_path

urls = {
    'main': 'http://k18.co/',
    'category': 'http://k18.co/?cat=',
}

loader = WebLoader(_cookie_dir, urls['main'])
parser = Parser(plugin, loader)


@plugin.route('/')
def main_screen():
    page = loader.load_page(urls['main'])
    list = parser.parse_categories(page)
    return compose_main_screen(list)

def compose_main_screen(list):
    items = []
    for item in list:
        path = plugin.url_for('category', id =item['id'])
        items.append({'label': item['title'], 'path': path, 'thumbnail': item['image']})
    return items

@plugin.route('/category/<id>')
def category(id):
    page = loader.load_page(urls['category']+id)
    list = parser.parse_videos(page)
    return compose_category(list)

def compose_category(list):
    items = []
    for item in list:
        path = plugin.url_for('play', url =item['url'])
        items.append({'label': item['title'], 'path': path, 'thumbnail': item['image']})
    return items

@plugin.route('/play/<url>')
def play(url):
    items = []
    page = loader.load_page(url)
    url_frame = parser.parse_play(page)
    frame = loader.load_page(url_frame)
    video = parser.decode_openload(frame)
    items.append({'label': 'Play', 'path': video['videourl'], 'thumbnail': video['image'], 'is_playable': True})
    return items

if __name__ == '__main__':
    plugin.run()
    plugin.set_content('movies')

