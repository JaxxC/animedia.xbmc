#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import requests
import re
from bs4 import BeautifulSoup

class Parser():
    def __init__(self, plugin, loader):
        self.plugin = plugin
        self.loader = loader

    def parse_categories(self, page):
        beautifulSoup = BeautifulSoup(page, "html.parser")
        cats = beautifulSoup.findAll('option', attrs={'class': 'level-0'})
        list = []
        for item in cats:
            list.append({
                'title': item.text,
                'id': item['value'],
                'image': ''
            })
        return list

    def parse_videos(self, page):
        beautifulSoup = BeautifulSoup(page, "html.parser")
        vids = beautifulSoup.find('div', attrs={'id': 'mh-infinite'}).findAll('div', attrs={'class': 'content-list-thumb'})
        list = []
        for item in vids:
            img = item.find('img');
            a = item.find('a')
            list.append({
                'title': a['title'],
                'url': a['href'],
                'image': img['src']
            })
        return list

    def parse_play(self, page):
        beautifulSoup = BeautifulSoup(page, "html.parser")
        iframe = beautifulSoup.find('iframe')
        return iframe['src']

    def decode_openload(self,html):
        aastring = re.search(r"<video(?:.|\s)*?<script\s[^>]*?>((?:.|\s)*?)</script", html,
                             re.DOTALL | re.IGNORECASE)

        info = re.findall('poster="(.*)" class', aastring.group(0))
        aastring = aastring.group(1).replace("((ﾟｰﾟ) + (ﾟｰﾟ) + (ﾟΘﾟ))", "9")
        aastring = aastring.replace("((ﾟｰﾟ) + (ﾟｰﾟ))", "8")
        aastring = aastring.replace("((ﾟｰﾟ) + (o^_^o))", "7")
        aastring = aastring.replace("((o^_^o) +(o^_^o))", "6")
        aastring = aastring.replace("((ﾟｰﾟ) + (ﾟΘﾟ))", "5")
        aastring = aastring.replace("(ﾟｰﾟ)", "4")
        aastring = aastring.replace("((o^_^o) - (ﾟΘﾟ))", "2")
        aastring = aastring.replace("(o^_^o)", "3")
        aastring = aastring.replace("(ﾟΘﾟ)", "1")
        aastring = aastring.replace("(+!+[])", "1")
        aastring = aastring.replace("(c^_^o)", "0")
        aastring = aastring.replace("(0+0)", "0")
        aastring = aastring.replace("(ﾟДﾟ)[ﾟεﾟ]", "\\")
        aastring = aastring.replace("(3 +3 +0)", "6")
        aastring = aastring.replace("(3 - 1 +0)", "2")
        aastring = aastring.replace("(!+[]+!+[])", "2")
        aastring = aastring.replace("(-~-~2)", "4")
        aastring = aastring.replace("(-~-~1)", "3")

        decodestring = re.search(r"\\\+([^(]+)", aastring, re.DOTALL | re.IGNORECASE).group(1)
        decodestring = "\\+" + decodestring
        decodestring = decodestring.replace("+", "")
        decodestring = decodestring.replace(" ", "")

        decodestring = self.decode(decodestring)
        decodestring = decodestring.replace("\\/", "/")

        videourl = re.search(r"vr\s?=\s?\"|'([^\"']+)", decodestring, re.DOTALL | re.IGNORECASE).group(1)

        return {'videourl': videourl, 'image':info[0]}

    def decode(self,encoded):
        for octc in (c for c in re.findall(r'\\(\d{2,3})', encoded)):
            encoded = encoded.replace(r'\%s' % octc, chr(int(octc, 8)))
        return encoded.decode('utf8')

    # def getHLS(self, path, hash):
    #     return path + 'smil:' + hash + '.smil/playlist.m3u8'
    #
    # def getImgThumb(self, image):
    #     imagename = re.findall('.*/(.*)\.jpg', image)
    #     return 'http://online.animedia.tv/images/made/images/uploads/'+imagename[0].replace('_280_385', '')+'_280_385.jpg'
