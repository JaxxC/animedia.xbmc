#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import requests
import re

from bs4 import BeautifulSoup

URL_NEW = 'http://online.animedia.tv/new'
URL_ALL = 'http://online.animedia.tv/list'
URL_TOP = 'http://online.animedia.tv'
URL_COMPLETED = 'http://online.animedia.tv/completed'
URL_GENRE = 'http://online.animedia.tv/category/'


class AnimediaParser():
    def __init__(self):
        self.genres = {
            'martial-arts': u"Боевые искусства",
            'vampires': u"Вампиры",
            'war': u"Война",
            'detective': u"Детектив",
            'dzesey': u"ДзёСэй",
            'dorams': u"Дорамы",
            'drama': u"Драма",
            'historical': u"Исторический",
            'history': u"История",
            'cyberpunk': u"Киберпанк",
            'comedy': u"Комедия",
            'crime': u"Криминал",
            'live': u"Лайв-экшн",
            'magicalgirl': u"Махо-сёдзё",
            'medicine': u"Медицина",
            'mecha': u"Меха",
            'mistery': u"Мистика",
            'music': u"Музыка",
            'parody': u"Пародия",
            'slice-of-Life': u"Повседневность",
            'postapokaliptika': u"Постапокалиптика",
            'advanture': u"Приключения",
            'psychology': u"Психология",
            'romance': u"Романтика",
            'samurai-action': u"Самурайский боевик",
            'shoujo': u"Сёдзе",
            'sedze-ai': u"Сёдзё-Ай",
            'shounen': u"Сёнэн",
            'shounen-ai': u"Сёнэн-Ай",
            'sport': u"Спорт",
            'seinen': u"Сэйнэн",
            'thriller': u"Триллер",
            'horror': u"Ужасы",
            'fantastika': u"Фантастика",
            'fantasy': u"Фэнтези",
            'school': u"Школа",
            'ecchi': u"Этти"
        }


    def parseGenresDir(self):
        listGenres = []
        for listItem in self.genres:
            listGenres.append({
                'image': '',
                'title': self.genres[listItem],
                'url': URL_GENRE + listItem,
            })

        return listGenres

    def parseNewDir(self,page):
        beautifulSoup = BeautifulSoup(page, "html.parser")
        listVideos = []
        listA = beautifulSoup.findAll('div', attrs={'class': 'new-series'})

        for listItem in listA:
            img = listItem.find('img')
            a = listItem.find('a', attrs = {'class': 'h4 widget__new-series__item__title'})
            if a:
                listVideos.append({
                    'title': a.text,
                    'url': URL_TOP +'/anime/'+ a['href'].split('/')[2],
                    'image': img['src']
                })

        return listVideos

    def parseTopDir(self,page):
        beautifulSoup = BeautifulSoup(page)
        listVideos = []
        listA = beautifulSoup.findAll('div', attrs={'class': 'widget__most-popular__item widget__item'})
        for listItem in listA:
            a = listItem.find('a', attrs = {'class': 'h4 widget__most-popular__item__title'})
            if a:
                listVideos.append({
                    'title': '[' + listItem.find('div', attrs = {'class': 'widget__most-popular__item__rating'}).text+ ']' + a.text,
                    'url': a.get('href').encode('utf-8', 'replace'),
                    'image': ''
                })

        return listVideos

    def parseFullDir(self,page):
        beautifulSoup = BeautifulSoup(page, "html.parser")
        listVideos = []
        listA = beautifulSoup.findAll('div', attrs={'class': 'ads-list__item'})

        for listItem in listA:
            img = listItem.find('img')
            a = listItem.find('a', attrs = {'class': 'h3 ads-list__item__title'})
            if a:
                listVideos.append({
                    'title': a.text + '/'+ listItem.find('div', attrs = {'class': 'original-title'}).text,
                    'url': a['href'],
                    'image': img['src']
                })

        return listVideos

    def parseSeasonsTab(self, page):
        beautifulSoup = BeautifulSoup(page, "html.parser")
        listSeasons = []
        seasons = beautifulSoup.findAll('a', attrs={'role': 'tab'})
        image =  beautifulSoup.find('a', attrs={'class': 'zoomLink'}).find('img')
        entry = beautifulSoup.find('ul', attrs={'class': 'media__tabs__nav nav-tabs'})
        entry_id = entry['data-entry_id']
        for season in seasons:
            listSeasons.append({
                'title': season.text,
                'url': 'http://online.animedia.tv/ajax/episodes/'+entry_id+'/'+ str(int(season['href'].replace('#tab', ''))+ 1),
                'image': image['src']
            })

        return listSeasons

    def parseVideos(self, page, loader):
        beautifulSoup = BeautifulSoup(page, "html.parser")
        listVideos = []
        name = re.findall('media__tabs__series__list__item"><a href="/anime/([^/]+)/', page)
        videos = beautifulSoup.findAll('div', attrs={'class': 'media__tabs__series__list__item'})
        first = videos[0].find('a');
        page2 = loader.load_page(URL_TOP + first['href'])
        videos2 = re.findall('data-layzr="([^"]*).*multiple="yes"}([^{]+)/playlist.m3u8[^<]*</a>[^<]*<span>(.*)</span>', page2, re.MULTILINE)
        if videos2:
            return self.newVideos(videos2)
        else:
            return self.oldVideos(videos)

    def oldVideos(self, videos):
        listVideos = []
        for video in videos:
            url = video.find('img')
            stream = url['data-layzr'].replace('http://online.animedia.tv/screens/', '').replace('_min.jpg', '')
            video_all_users = 'http://37.59.28.83:8081/' + name[0] + '/smil:' + stream + '.smil/playlist.m3u8'
            video_nohls = 'http://37.59.28.83:8081/' + name[0] + '/' + stream + '.mp4';
            listVideos.append({
                'title': video.text,
                'url': video_nohls,
                'image': url['data-layzr']
            })
        return listVideos

    def newVideos(self, videos):
        listVideos = []
        for video in videos:
            print video[2]
            listVideos.append({
                'title': video[2].decode('utf-8'),
                'url': video[1],
                'image': video[0]
            })
        return listVideos